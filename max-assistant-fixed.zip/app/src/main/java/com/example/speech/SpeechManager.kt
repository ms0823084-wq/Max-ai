package com.example.speech

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.example.data.local.SecurityManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.sqrt

class SpeechManager(
    private val context: Context,
    private val securityManager: SecurityManager,
    private val listener: SpeechEventsListener
) {

    interface SpeechEventsListener {
        fun onWakeWordDetected(keyword: String)
        fun onCommandRecognized(command: String)
        fun onPartialSpeech(partial: String)
        fun onRmsChanged(rmsDb: Float)
        fun onSpeechError(error: String)
        fun onListeningStateChanged(isListening: Boolean)
    }

    private var speechRecognizer: SpeechRecognizer? = null
    private var isRecognizerActive = false
    private var vadJob: Job? = null
    private var audioRecord: AudioRecord? = null
    private var autoGainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    var isContinuousListeningEnabled = false
        private set

    fun initialize() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            listener.onSpeechError("Speech recognition service not available on this device.")
            return
        }
        setupRecognizer()
    }

    private fun setupRecognizer() {
        try {
            speechRecognizer?.destroy()
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        listener.onListeningStateChanged(true)
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        listener.onRmsChanged(rmsdB)
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        listener.onListeningStateChanged(false)
                    }

                    override fun onError(error: Int) {
                        isRecognizerActive = false
                        listener.onListeningStateChanged(false)
                        // If continuous listening is enabled, restart after a brief moment unless client cancelled
                        if (isContinuousListeningEnabled && error != SpeechRecognizer.ERROR_CLIENT) {
                            scope.launch(Dispatchers.Main) {
                                kotlinx.coroutines.delay(800)
                                if (isContinuousListeningEnabled) {
                                    startListening()
                                }
                            }
                        }
                    }

                    override fun onResults(results: Bundle?) {
                        isRecognizerActive = false
                        listener.onListeningStateChanged(false)
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val recognizedText = matches[0].trim()
                            processRecognizedText(recognizedText)
                        }

                        // Loop if continuous
                        if (isContinuousListeningEnabled) {
                            scope.launch(Dispatchers.Main) {
                                kotlinx.coroutines.delay(400)
                                if (isContinuousListeningEnabled) {
                                    startListening()
                                }
                            }
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val partial = matches[0].trim()
                            listener.onPartialSpeech(partial)

                            // Check wake word on partial match for zero-latency activation
                            checkWakeWord(partial)
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        } catch (e: Exception) {
            Log.e("SpeechManager", "Error creating SpeechRecognizer", e)
        }
    }

    fun startListening() {
        if (isRecognizerActive) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf("en-IN", "en-US", "hi"))
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        try {
            isRecognizerActive = true
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            isRecognizerActive = false
            Log.e("SpeechManager", "Failed to start listening", e)
        }
    }

    fun stopListening() {
        isContinuousListeningEnabled = false
        isRecognizerActive = false
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (e: Exception) {
            // Ignored
        }
        listener.onListeningStateChanged(false)
        stopVadRecording()
    }

    fun enableAlwaysListening() {
        isContinuousListeningEnabled = true
        startListening()
        startVadRecording()
    }

    /**
     * Hardware AGC and Noise Suppressor AudioRecord loop for hearing soft voices & VAD energy.
     */
    private fun startVadRecording() {
        if (audioRecord != null) return
        val sampleRate = 16000
        val channelConfig = AudioFormat.CHANNEL_IN_MONO
        val audioFormat = AudioFormat.ENCODING_PCM_16BIT
        val bufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat).coerceAtLeast(2048)

        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                channelConfig,
                audioFormat,
                bufferSize
            )

            val sessionId = audioRecord?.audioSessionId ?: 0
            if (sessionId != 0) {
                // Enable Automatic Gain Control for hearing soft voices
                if (AutomaticGainControl.isAvailable()) {
                    autoGainControl = AutomaticGainControl.create(sessionId)?.apply {
                        enabled = true
                    }
                }
                // Enable Noise Suppressor
                if (NoiseSuppressor.isAvailable()) {
                    noiseSuppressor = NoiseSuppressor.create(sessionId)?.apply {
                        enabled = true
                    }
                }
            }

            audioRecord?.startRecording()

            vadJob = scope.launch(Dispatchers.IO) {
                val buffer = ShortArray(1024)
                while (isActive && audioRecord?.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val readCount = audioRecord?.read(buffer, 0, buffer.size) ?: 0
                    if (readCount > 0) {
                        var sum = 0.0
                        for (i in 0 until readCount) {
                            sum += buffer[i] * buffer[i]
                        }
                        val rms = sqrt(sum / readCount)
                        val db = if (rms > 0) 20 * Math.log10(rms) else 0.0
                        // Notify VAD changes for visualizer
                        listener.onRmsChanged(db.toFloat())
                    }
                }
            }
        } catch (e: SecurityException) {
            Log.e("SpeechManager", "Record audio permission not granted for VAD", e)
        } catch (e: Exception) {
            Log.e("SpeechManager", "Failed to start VAD AudioRecord", e)
        }
    }

    private fun stopVadRecording() {
        vadJob?.cancel()
        vadJob = null
        try {
            autoGainControl?.release()
            autoGainControl = null
            noiseSuppressor?.release()
            noiseSuppressor = null
            audioRecord?.stop()
            audioRecord?.release()
            audioRecord = null
        } catch (e: Exception) {
            // Ignored
        }
    }

    private fun checkWakeWord(text: String): Boolean {
        val configuredWakeWord = securityManager.wakeWord.lowercase(Locale.ROOT)
        val assistantName = securityManager.assistantName.lowercase(Locale.ROOT)
        val normalized = text.lowercase(Locale.ROOT)

        if (normalized.contains(configuredWakeWord) ||
            normalized.contains("bolo $assistantName") ||
            normalized.contains("hey $assistantName") ||
            normalized.contains("suno $assistantName") ||
            normalized.contains("ok $assistantName") ||
            normalized.contains("bolo max") ||
            normalized.contains("hey max")
        ) {
            listener.onWakeWordDetected(configuredWakeWord)
            return true
        }
        return false
    }

    private fun processRecognizedText(text: String) {
        val configuredWakeWord = securityManager.wakeWord.lowercase(Locale.ROOT)
        val assistantName = securityManager.assistantName.lowercase(Locale.ROOT)
        var command = text

        val isWakeMatch = checkWakeWord(text)
        if (isWakeMatch) {
            // Strip wake word prefix if user said "Bolo Max YouTube kholo"
            val lower = text.lowercase(Locale.ROOT)
            val wakePrefixes = listOf(
                configuredWakeWord,
                "bolo $assistantName",
                "hey $assistantName",
                "suno $assistantName",
                "ok $assistantName",
                "bolo max",
                "hey max"
            )
            for (prefix in wakePrefixes) {
                if (lower.startsWith(prefix)) {
                    command = text.substring(prefix.length).trim().removePrefix(",").trim()
                    break
                }
            }
        }

        if (command.isNotBlank()) {
            listener.onCommandRecognized(command)
        }
    }

    fun destroy() {
        stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }
}
