package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.MaxApplication

class PowerConnectionReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (context == null || intent == null) return
        if (intent.action == Intent.ACTION_POWER_DISCONNECTED) {
            Log.d("PowerReceiver", "Power disconnected")
            val app = context.applicationContext as? MaxApplication ?: return
            if (app.securityManager.isAntiTheftArmed && app.securityManager.isChargerAlarmEnabled) {
                app.antiTheftController.triggerAlarm("Charger Unplugged While Armed")
            }
        }
    }
}
