package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class MaxAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: MaxAccessibilityService? = null
            private set

        val isServiceRunning: Boolean
            get() = instance != null
    }

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d("MaxAccessibility", "MaxAccessibilityService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Track window/state transitions if needed
    }

    override fun onInterrupt() {
        Log.w("MaxAccessibility", "Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
        }
    }

    // -------------------------------------------------------------
    // SYSTEM NAVIGATION ACTIONS
    // -------------------------------------------------------------
    fun triggerHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun triggerBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun triggerRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun triggerNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun triggerLockScreen(): Boolean = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    fun triggerScreenshot(): Boolean = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    // -------------------------------------------------------------
    // GESTURES: TAP, SWIPE, SCROLL
    // -------------------------------------------------------------
    fun tapAt(x: Float, y: Float, onComplete: (() -> Unit)? = null): Boolean {
        val path = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 100)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke()
            }
        }, null)
    }

    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300, onComplete: (() -> Unit)? = null): Boolean {
        val path = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, durationMs)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                onComplete?.invoke()
            }
        }, null)
    }

    fun scrollUp(): Boolean {
        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()
        return swipe(width / 2, height * 0.75f, width / 2, height * 0.25f, 350)
    }

    fun scrollDown(): Boolean {
        val displayMetrics = resources.displayMetrics
        val width = displayMetrics.widthPixels.toFloat()
        val height = displayMetrics.heightPixels.toFloat()
        return swipe(width / 2, height * 0.25f, width / 2, height * 0.75f, 350)
    }

    fun swipeNextReel(): Boolean {
        // Reel scroll up
        return scrollUp()
    }

    fun swipePreviousReel(): Boolean {
        // Reel scroll down
        return scrollDown()
    }

    fun doubleTapLike(): Boolean {
        val displayMetrics = resources.displayMetrics
        val cx = displayMetrics.widthPixels / 2f
        val cy = displayMetrics.heightPixels / 2f
        tapAt(cx, cy) {
            tapAt(cx, cy)
        }
        return true
    }

    // -------------------------------------------------------------
    // SCREEN CAPTURE (API 30+)
    // -------------------------------------------------------------
    fun captureCurrentScreen(callback: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                mainExecutor,
                object : TakeScreenshotCallback {
                    override fun onSuccess(screenshot: ScreenshotResult) {
                        val hardwareBitmap = Bitmap.wrapHardwareBuffer(
                            screenshot.hardwareBuffer,
                            screenshot.colorSpace
                        )
                        val copy = hardwareBitmap?.copy(Bitmap.Config.ARGB_8888, false)
                        screenshot.hardwareBuffer.close()
                        callback(copy)
                    }

                    override fun onFailure(errorCode: Int) {
                        Log.e("MaxAccessibility", "Screenshot failed with code $errorCode")
                        callback(null)
                    }
                }
            )
        } else {
            callback(null)
        }
    }

    // -------------------------------------------------------------
    // NODE SEARCH & CLICK BY TEXT
    // -------------------------------------------------------------
    fun clickNodeWithText(queryText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val found = findNodeByTextRecursive(root, queryText.trim())
        if (found != null) {
            val clicked = performClickOnNode(found)
            found.recycle()
            return clicked
        }
        return false
    }

    private fun findNodeByTextRecursive(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        val nodeText = node.text?.toString()
        val nodeDesc = node.contentDescription?.toString()
        if ((nodeText != null && nodeText.contains(text, ignoreCase = true)) ||
            (nodeDesc != null && nodeDesc.contains(text, ignoreCase = true))
        ) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findNodeByTextRecursive(child, text)
            if (result != null) {
                return result
            }
            child.recycle()
        }
        return null
    }

    private fun performClickOnNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            val parent = current.parent
            current = parent
        }
        // Fallback: tap at bounding rectangle coordinates
        val rect = Rect()
        node.getBoundsInScreen(rect)
        if (!rect.isEmpty) {
            tapAt(rect.centerX().toFloat(), rect.centerY().toFloat())
            return true
        }
        return false
    }

    fun typeTextIntoFocused(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: rootInActiveWindow?.findAccessibilityNodeInfosByViewId("android:id/input")?.firstOrNull()
        if (focused != null) {
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            val res = focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            focused.recycle()
            return res
        }
        return false
    }

    // -------------------------------------------------------------
    // ML KIT SCREEN OCR CLICKS (Tapping text even with no accessibility labels!)
    // -------------------------------------------------------------
    fun clickTextViaOcr(targetText: String, onResult: (Boolean, String) -> Unit) {
        captureCurrentScreen { bitmap ->
            if (bitmap == null) {
                onResult(false, "Could not capture screen for OCR.")
                return@captureCurrentScreen
            }
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    var matchedBox: Rect? = null
                    var matchedWord = ""
                    val query = targetText.trim().lowercase()

                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            if (line.text.lowercase().contains(query)) {
                                matchedBox = line.boundingBox
                                matchedWord = line.text
                                break
                            }
                            for (element in line.elements) {
                                if (element.text.lowercase().contains(query) ||
                                    query.contains(element.text.lowercase())
                                ) {
                                    matchedBox = element.boundingBox
                                    matchedWord = element.text
                                    break
                                }
                            }
                            if (matchedBox != null) break
                        }
                        if (matchedBox != null) break
                    }

                    if (matchedBox != null) {
                        val cx = matchedBox.centerX().toFloat()
                        val cy = matchedBox.centerY().toFloat()
                        tapAt(cx, cy)
                        onResult(true, "Found '$matchedWord' at ($cx, $cy) and tapped it.")
                    } else {
                        onResult(false, "Text '$targetText' not found on current screen.")
                    }
                }
                .addOnFailureListener { e ->
                    onResult(false, "OCR failed: ${e.message}")
                }
        }
    }
}
